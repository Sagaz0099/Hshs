"""
This module will contain various attributes useful for testing and cog development.
"""

testing = False
