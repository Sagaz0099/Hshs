And activate it with the following command:

.. prompt:: bash

    source ~/redenv/bin/activate

.. important::

    You must activate the virtual environment with the above command every time you open a new
    shell to run, install or update Red.
