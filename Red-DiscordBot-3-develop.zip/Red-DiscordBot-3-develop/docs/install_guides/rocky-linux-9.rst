.. _install-rocky-linux-9:

===============================
Installing Red on Rocky Linux 9
===============================

.. include:: _includes/install-guide-rhel9-derivatives.rst
