.. _install-rhel-9:

===================================================
Installing Red on Red Hat Enterprise Linux (RHEL) 9
===================================================

.. include:: _includes/install-guide-rhel9-derivatives.rst
