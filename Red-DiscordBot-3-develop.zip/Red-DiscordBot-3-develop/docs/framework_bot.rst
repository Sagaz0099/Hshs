.. bot module docs

===
Bot
===

.. automodule:: redbot.core.bot

Red
^^^

.. autoclass:: Red
    :members:
    :exclude-members: get_context, get_embed_color

    .. automethod:: register_rpc_handler
    .. automethod:: unregister_rpc_handler
