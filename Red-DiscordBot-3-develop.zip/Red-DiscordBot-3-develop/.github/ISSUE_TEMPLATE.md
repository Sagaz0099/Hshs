<!-- 
Please be sure to use the correct template, 
if your report doesn't have the correct template please open an issue describing your issue in detail
For support regarding the bot itself please visit the discord server over at https://discord.gg/red
-->
